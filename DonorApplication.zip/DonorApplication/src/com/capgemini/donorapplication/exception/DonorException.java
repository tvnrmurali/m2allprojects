package com.capgemini.donorapplication.exception;

public class DonorException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public DonorException(String message) 
	{
		
		super(message);
	}
}
